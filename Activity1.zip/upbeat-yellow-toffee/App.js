import React from 'react';
import {View, Text, Image, ScrollView, TextInput} from 'react-native';

const App = () => {
  return (
    <ScrollView>
      <View 
      style={{
        justifyContent: 'center',
        alignItems: 'center',
      }}>
      <Text>Joy Bermejo</Text>
        <Text>IT-302</Text>
        <Image
          source={{
            uri: 'https://th.bing.com/th/id/OIP.de7bd9A1W4resyaOHPu9FAHaF7?w=800&h=640&rs=1&pid=ImgDetMain',
          }}
          style={{width: 200, height: 200, justifyContent: 'center',
        alignItems: 'center',}}
        />
      </View>
      <TextInput
        style={{
          height: 40,
          borderColor: 'gray',
          borderWidth: 1,
        }}
        defaultValue="You can type in me"
      />
    </ScrollView>
  );
};

export default App;